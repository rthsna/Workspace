import java.awt.EventQueue;
import java.awt.List;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.WindowConstants;

import model.LIVRE;

public class Frame_Livres {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(ArrayList<LIVRE> lesLivres) {
		System.out.println(lesLivres.size());

		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					Frame_Livres window = new Frame_Livres();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Frame_Livres() {
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {

		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		List list = new List();
		list.setBounds(31, 46, 211, 110);
		frame.getContentPane().add(list);
		String str ;

		System.out.println(main.LesLivres.size());
		for (LIVRE element : main.LesLivres) {
			str = element.getISBN()+" : "+element.getTitre();
			list.add(str);
		}



	}
}
