import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.WindowConstants;

import controller.mainMVC;

public class Accueil {

	private JFrame frame;

	/**
	 * Create the application.
	 */
	public Accueil() {
		initialize();
		System.out.println(mainMVC.m.getListLivre().size());
		frame.setVisible(true);

	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JButton btnNewButton = new JButton("New button");
		btnNewButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				ViewLivre window= new ViewLivre();
			}
		});
		btnNewButton.setBounds(93, 23, 203, 110);
		frame.getContentPane().add(btnNewButton);

	}

}
