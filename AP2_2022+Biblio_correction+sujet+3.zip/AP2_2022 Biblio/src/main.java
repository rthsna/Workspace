import java.util.ArrayList;

import model.ADHERENT;
import model.AUTEUR;
import model.LIVRE;

import java.awt.EventQueue;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class main {
	static ArrayList<LIVRE> LesLivres=new ArrayList<> ();
	static ArrayList<AUTEUR> LesAuteur=new ArrayList<> ();
	static ArrayList<ADHERENT> LesAdherent=new ArrayList<> ();

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AUTEUR a1,a2;
		LIVRE l1,l2;
		ADHERENT ad1,ad2;
		a1=new AUTEUR("GRAVOUIL","Benjamin","12/09/1984","Le meilleur prof au monde !!!");
		a2=new AUTEUR("MARTIN","martin","12/09/1990","super auteur !");
		LesAuteur.add(a1);
		LesAuteur.add(a2);
		l1=new LIVRE("0001","Programmer en C",20, a1);
		l2=new LIVRE("0002","Programmer en java",20, a1);
		LesLivres.add(l1);
		LesLivres.add(l2);
		ad1=new ADHERENT ("bob","leponge","bob@eponge.fr");
		ad2=new ADHERENT ("super","man","super@man.fr");


		String BDD = "AP1";
		String url = "jdbc:mysql://localhost:3306/" + BDD;
		String user = "root";
		String passwd = "";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection(url, user, passwd);
			System.out.println("Connection OK");


			ResultSet r�sultats;
			String requete = "SELECT * FROM utilisateur";

			try {
				Statement stmt = conn.createStatement();
				r�sultats = stmt.executeQuery(requete);
				System.out.println("ok");
				while (r�sultats.next()) {
					System.out.println(r�sultats.getInt(1) + " :  "+r�sultats.getString(2)+" ");
				}

			} catch (SQLException e) {
				//traitement de l'exception
				e.printStackTrace();
				System.out.println("Erreur");
				System.exit(0);
			}

			requete = "INSERT INTO tuteur VALUES (null,'test','test',null,null)";
			try {
				Statement stmt2 = conn.createStatement();
				int maj = stmt2.executeUpdate(requete);
			} catch (SQLException e) {
				e.printStackTrace();
			}

		} catch (Exception e){
			e.printStackTrace();
			System.out.println("Erreur");
			System.exit(0);
		}



		l1.setEmprunteur(ad1);


		ad1.getListLivre().add(l1);


		Accueil window = new Accueil();

	}
}