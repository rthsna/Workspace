package view;

import java.awt.EventQueue;
import java.sql.SQLException;

import javax.swing.JFrame;

import controller.mainMVC;
import model.AUTEUR;
import model.LIVRE;

import java.awt.List;

public class View_Auteur {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					View_Auteur window = new View_Auteur();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public View_Auteur() {
		try {
			mainMVC.getM().getAll();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			initialize();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 * @throws SQLException 
	 */
	private void initialize() throws SQLException {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		List list_auteur = new List();
		list_auteur.setBounds(48, 44, 289, 167);
		frame.getContentPane().add(list_auteur);
		
		for (AUTEUR element : mainMVC.getM().getListAuteur()) {
			int nb = mainMVC.getM().nb_livre_auteur(element.getNum());
			
			list_auteur.add(element.getNom()+" - "+element.getPrenom()+"- "+element.getDate_naissance()+ " - nblivre:"+nb);

		}

	}
}
