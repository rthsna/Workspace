package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.WindowConstants;

public class View_Accueil {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	/*
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					View_Accueil window = new View_Accueil();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
*/
	/**
	 * Create the application.
	 */
	public View_Accueil() {
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JButton btn_Livre = new JButton("Liste des Livres");
		btn_Livre.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				View_Livre vl;
				try {
					vl = new View_Livre();
					//vl.main(null);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});
		btn_Livre.setBounds(25, 104, 167, 28);
		frame.getContentPane().add(btn_Livre);

		JButton btn_resa = new JButton("R\u00E9server un livre");
		btn_resa.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				View_resa vr = new View_resa();

			}
		});
		btn_resa.setBounds(229, 106, 167, 26);
		frame.getContentPane().add(btn_resa);

		JButton btnCrationAdhrent = new JButton("Cr\u00E9ation Adh\u00E9rent");
		btnCrationAdhrent.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				View_CreationAdherent vca= new View_CreationAdherent();
			}
		});
		btnCrationAdhrent.setBounds(116, 178, 167, 23);
		frame.getContentPane().add(btnCrationAdhrent);
		
		JButton btnNewButton = new JButton("Voir Auteurs");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				View_Auteur va= new View_Auteur();
			}
		});
		btnNewButton.setBounds(136, 214, 158, 23);
		frame.getContentPane().add(btnNewButton);
	}
}
