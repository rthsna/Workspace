package controller;

import java.awt.EventQueue;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class test {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					test window = new test();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public test() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel message = new JLabel("Bienvenue à la Bibliothèque Paul Lapie");
		message.setBounds(10, 175, 247, 37);
		frame.getContentPane().add(message);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\Gravouil\\Downloads\\téléchargement2.png"));
		btnNewButton.setBounds(77, 24, 175, 60);
		frame.getContentPane().add(btnNewButton);

	
		Timer timer = new Timer();

		TimerTask task = new TimerTask() {

			// run() m ethod to carry out the action of the task
			public void run() {
				//System.out.println("ok");
				if (frame.getBounds().width>message.getBounds().x)
					message.setBounds(message.getBounds().x+10, 
							message.getBounds().y,
							message.getBounds().width, 
							message.getBounds().height);
				else
					message.setBounds(-message.getBounds().width, 
							message.getBounds().y,
							message.getBounds().width, 
							message.getBounds().height);
				//timer.cancel();


			};
		};
		/*
		 *  schedule() method to schedule the execution with start time
		 */

		timer.schedule(task,100,100);
		System.out.println("stop");



	}
}
